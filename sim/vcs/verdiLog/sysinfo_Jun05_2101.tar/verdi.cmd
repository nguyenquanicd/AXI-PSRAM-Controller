verdiWindowResize -win $_Verdi_1 "0" "0" "1604" "760"
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
simSetSimulator "-vcssv" -exec "/home/ltthinh/PSRAM_CTRL/sim/vcs/simv" -args
debImport "-dbdir" "/home/ltthinh/PSRAM_CTRL/sim/vcs/simv.daidir"
wvCreateWindow
verdiSetActWin -win $_nWave2
wvSetPosition -win $_nWave2 {("G1" 0)}
wvOpenFile -win $_nWave2 {/home/ltthinh/PSRAM_CTRL/sim/vcs/test_top.fsdb}
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvSetPosition -win $_nWave2 {("G1" 49)}
wvSetPosition -win $_nWave2 {("G1" 49)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/i_aclk} -height 16 \
{/test_top/u_dut_wrapper/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_aresetn} -height 16 \
{/test_top/u_dut_wrapper/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/i_awaddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_awburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_awid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_awlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_awvalid} -height 16 \
{/test_top/u_dut_wrapper/i_bready} -height 16 \
{/test_top/u_dut_wrapper/i_paddr\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_pclk} -height 16 \
{/test_top/u_dut_wrapper/i_penable} -height 16 \
{/test_top/u_dut_wrapper/i_pprot\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_presetn} -height 16 \
{/test_top/u_dut_wrapper/i_protect_en} -height 16 \
{/test_top/u_dut_wrapper/i_psel} -height 16 \
{/test_top/u_dut_wrapper/i_pstrb\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_pwdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_pwrite} -height 16 \
{/test_top/u_dut_wrapper/i_qspi_clk} -height 16 \
{/test_top/u_dut_wrapper/i_qspi_rstn} -height 16 \
{/test_top/u_dut_wrapper/i_rready} -height 16 \
{/test_top/u_dut_wrapper/i_slverr_en} -height 16 \
{/test_top/u_dut_wrapper/i_wdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_wlast} -height 16 \
{/test_top/u_dut_wrapper/i_wvalid} -height 16 \
{/test_top/u_dut_wrapper/o_arready} -height 16 \
{/test_top/u_dut_wrapper/o_awready} -height 16 \
{/test_top/u_dut_wrapper/o_bid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/o_bresp\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/o_bvalid} -height 16 \
{/test_top/u_dut_wrapper/o_prdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/o_pready} -height 16 \
{/test_top/u_dut_wrapper/o_pslverr} -height 16 \
{/test_top/u_dut_wrapper/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/o_rid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/o_rlast} -height 16 \
{/test_top/u_dut_wrapper/o_rresp\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/o_wready} -height 16 \
{/test_top/u_dut_wrapper/qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/qspi_sclk} -height 16 \
{/test_top/u_dut_wrapper/qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/qspi_so\[3:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
}
wvSelectSignal -win $_nWave2 {( "G1" 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 \
           18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 \
           40 41 42 43 44 45 46 47 48 49 )} 
wvSetPosition -win $_nWave2 {("G1" 49)}
wvGetSignalClose -win $_nWave2
wvSetCursor -win $_nWave2 194129870.129870 -snap {("G1" 41)}
wvZoomAll -win $_nWave2
wvZoom -win $_nWave2 0.000000 370642201.834862
wvZoom -win $_nWave2 0.000000 24531364.603749
wvZoom -win $_nWave2 1848693.924922 4790528.605450
wvZoom -win $_nWave2 3229004.299272 3626132.703066
wvZoomOut -win $_nWave2
verdiDockWidgetMaximize -dock windowDock_nWave_2
wvSelectSignal -win $_nWave2 {( "G1" 18 )} 
wvSelectSignal -win $_nWave2 {( "G1" 18 )} 
wvSelectSignal -win $_nWave2 {( "G1" 49 )} 
wvSelectSignal -win $_nWave2 {( "G1" 48 )} 
wvSelectSignal -win $_nWave2 {( "G1" 46 )} 
wvSelectSignal -win $_nWave2 {( "G1" 23 )} 
wvSetCursor -win $_nWave2 893129.380026 -snap {("G1" 23)}
wvSetCursor -win $_nWave2 1087269.477818 -snap {("G1" 24)}
wvSetCursor -win $_nWave2 1088310.443489 -snap {("G1" 23)}
wvSetCursor -win $_nWave2 2837809.399807 -snap {("G1" 22)}
wvScrollDown -win $_nWave2 0
wvScrollUp -win $_nWave2 4
wvScrollUp -win $_nWave2 3
wvScrollUp -win $_nWave2 3
wvScrollUp -win $_nWave2 2
wvScrollUp -win $_nWave2 5
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvSelectSignal -win $_nWave2 {( "G1" 1 )} 
wvSelectSignal -win $_nWave2 {( "G1" 2 )} 
wvSelectSignal -win $_nWave2 {( "G1" 3 )} 
wvScrollDown -win $_nWave2 0
wvSelectSignal -win $_nWave2 {( "G1" 2 )} 
wvSelectSignal -win $_nWave2 {( "G1" 3 )} 
wvSelectSignal -win $_nWave2 {( "G1" 4 )} 
wvSelectSignal -win $_nWave2 {( "G1" 3 )} 
wvSelectSignal -win $_nWave2 {( "G1" 4 )} 
wvScrollDown -win $_nWave2 0
wvSelectSignal -win $_nWave2 {( "G1" 1 )} 
wvSelectSignal -win $_nWave2 {( "G1" 1 )} 
wvSelectSignal -win $_nWave2 {( "G1" 2 )} 
wvScrollDown -win $_nWave2 0
wvSetCursor -win $_nWave2 3753685.641653 -snap {("G1" 2)}
wvSelectSignal -win $_nWave2 {( "G1" 3 )} 
wvSelectSignal -win $_nWave2 {( "G1" 2 )} 
wvSelectSignal -win $_nWave2 {( "G1" 4 )} 
wvSelectSignal -win $_nWave2 {( "G1" 5 )} 
wvSelectSignal -win $_nWave2 {( "G1" 6 )} 
wvSelectSignal -win $_nWave2 {( "G1" 7 )} 
wvSetCursor -win $_nWave2 3766281.326282 -snap {("G1" 7)}
wvZoomOut -win $_nWave2
wvZoom -win $_nWave2 3713192.077020 3820411.541216
wvZoomOut -win $_nWave2
wvScrollDown -win $_nWave2 0
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arbiter"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvScrollDown -win $_nWave2 0
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvScrollDown -win $_nWave2 0
wvSelectSignal -win $_nWave2 {( "G1" 2 )} 
wvGetSignalOpen -win $_nWave2
wvGetSignalSetSignalFilter -win $_nWave2 "*arready*"
wvSetPosition -win $_nWave2 {("G1" 49)}
wvSetPosition -win $_nWave2 {("G1" 49)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/i_aclk} -height 16 \
{/test_top/u_dut_wrapper/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_aresetn} -height 16 \
{/test_top/u_dut_wrapper/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/i_awaddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_awburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_awid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_awlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_awvalid} -height 16 \
{/test_top/u_dut_wrapper/i_bready} -height 16 \
{/test_top/u_dut_wrapper/i_paddr\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_pclk} -height 16 \
{/test_top/u_dut_wrapper/i_penable} -height 16 \
{/test_top/u_dut_wrapper/i_pprot\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_presetn} -height 16 \
{/test_top/u_dut_wrapper/i_protect_en} -height 16 \
{/test_top/u_dut_wrapper/i_psel} -height 16 \
{/test_top/u_dut_wrapper/i_pstrb\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_pwdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_pwrite} -height 16 \
{/test_top/u_dut_wrapper/i_qspi_clk} -height 16 \
{/test_top/u_dut_wrapper/i_qspi_rstn} -height 16 \
{/test_top/u_dut_wrapper/i_rready} -height 16 \
{/test_top/u_dut_wrapper/i_slverr_en} -height 16 \
{/test_top/u_dut_wrapper/i_wdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/i_wlast} -height 16 \
{/test_top/u_dut_wrapper/i_wvalid} -height 16 \
{/test_top/u_dut_wrapper/o_arready} -height 16 \
{/test_top/u_dut_wrapper/o_awready} -height 16 \
{/test_top/u_dut_wrapper/o_bid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/o_bresp\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/o_bvalid} -height 16 \
{/test_top/u_dut_wrapper/o_prdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/o_pready} -height 16 \
{/test_top/u_dut_wrapper/o_pslverr} -height 16 \
{/test_top/u_dut_wrapper/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/o_rid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/o_rlast} -height 16 \
{/test_top/u_dut_wrapper/o_rresp\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/o_wready} -height 16 \
{/test_top/u_dut_wrapper/qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/qspi_sclk} -height 16 \
{/test_top/u_dut_wrapper/qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/qspi_so\[3:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
}
wvSetPosition -win $_nWave2 {("G1" 49)}
wvScrollUp -win $_nWave2 4
wvScrollUp -win $_nWave2 12
wvSelectSignal -win $_nWave2 {( "G1" 31 )} 
wvSetPosition -win $_nWave2 {("G1" 29)}
wvSetPosition -win $_nWave2 {("G1" 28)}
wvSetPosition -win $_nWave2 {("G1" 25)}
wvSetPosition -win $_nWave2 {("G1" 21)}
wvSetPosition -win $_nWave2 {("G1" 16)}
wvSetPosition -win $_nWave2 {("G1" 5)}
wvSetPosition -win $_nWave2 {("G1" 4)}
wvSetPosition -win $_nWave2 {("G1" 49)}
wvSetPosition -win $_nWave2 {("G1" 6)}
wvSetPosition -win $_nWave2 {("G1" 3)}
wvSetPosition -win $_nWave2 {("G1" 2)}
wvSetPosition -win $_nWave2 {("G1" 1)}
wvSetPosition -win $_nWave2 {("G1" 0)}
wvSetPosition -win $_nWave2 {("G1" 49)}
wvSetPosition -win $_nWave2 {("G1" 0)}
wvSetPosition -win $_nWave2 {("G1" 2)}
wvSetPosition -win $_nWave2 {("G1" 3)}
wvMoveSelected -win $_nWave2
wvSetPosition -win $_nWave2 {("G1" 3)}
wvSetPosition -win $_nWave2 {("G1" 4)}
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvSetCursor -win $_nWave2 3753016.449436 -snap {("G1" 8)}
wvSelectSignal -win $_nWave2 {( "G1" 6 )} 
wvSelectSignal -win $_nWave2 {( "G1" 8 )} 
wvSetCursor -win $_nWave2 3754130.417895 -snap {("G1" 8)}
wvSelectSignal -win $_nWave2 {( "G1" 8 )} 
wvSelectAll -win $_nWave2
wvCut -win $_nWave2
wvSetPosition -win $_nWave2 {("G1" 0)}
wvGetSignalOpen -win $_nWave2
wvGetSignalSetSignalFilter -win $_nWave2 "*ar*"
wvSetPosition -win $_nWave2 {("G1" 0)}
wvSetPosition -win $_nWave2 {("G1" 0)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
}
wvAddSignal -win $_nWave2 -group {"G2" \
}
wvSetPosition -win $_nWave2 {("G1" 0)}
wvSetPosition -win $_nWave2 {("G1" 6)}
wvSetPosition -win $_nWave2 {("G1" 6)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
}
wvSelectSignal -win $_nWave2 {( "G1" 1 2 3 4 5 6 )} 
wvSetPosition -win $_nWave2 {("G1" 6)}
wvGetSignalClose -win $_nWave2
wvSetCursor -win $_nWave2 3755940.616641 -snap {("G2" 0)}
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetSignalFilter -win $_nWave2 "*clk*"
wvSetPosition -win $_nWave2 {("G1" 6)}
wvSetPosition -win $_nWave2 {("G1" 6)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
}
wvSetPosition -win $_nWave2 {("G1" 6)}
wvSetPosition -win $_nWave2 {("G1" 8)}
wvSetPosition -win $_nWave2 {("G1" 8)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
}
wvSelectSignal -win $_nWave2 {( "G1" 7 8 )} 
wvSetPosition -win $_nWave2 {("G1" 8)}
wvGetSignalClose -win $_nWave2
wvSetPosition -win $_nWave2 {("G1" 4)}
wvSetPosition -win $_nWave2 {("G1" 6)}
wvSetPosition -win $_nWave2 {("G1" 4)}
wvSetPosition -win $_nWave2 {("G1" 3)}
wvSetPosition -win $_nWave2 {("G1" 0)}
wvSetPosition -win $_nWave2 {("G1" 1)}
wvSetPosition -win $_nWave2 {("G1" 0)}
wvSetPosition -win $_nWave2 {("G1" 1)}
wvMoveSelected -win $_nWave2
wvSetPosition -win $_nWave2 {("G1" 1)}
wvSetPosition -win $_nWave2 {("G1" 3)}
wvSetPosition -win $_nWave2 {("G1" 1)}
wvSetPosition -win $_nWave2 {("G1" 0)}
wvMoveSelected -win $_nWave2
wvSetPosition -win $_nWave2 {("G1" 0)}
wvSetPosition -win $_nWave2 {("G1" 2)}
wvSetCursor -win $_nWave2 3765409.348544 -snap {("G2" 0)}
wvSetCursor -win $_nWave2 3759978.752306 -snap {("G1" 2)}
wvSetCursor -win $_nWave2 3765130.856429 -snap {("G1" 1)}
wvSelectSignal -win $_nWave2 {( "G1" 7 )} 
wvSelectSignal -win $_nWave2 {( "G1" 8 )} 
wvSelectSignal -win $_nWave2 {( "G1" 7 )} 
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetSignalFilter -win $_nWave2 "*rdata*"
wvSetPosition -win $_nWave2 {("G1" 2)}
wvSetPosition -win $_nWave2 {("G1" 2)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
}
wvSetPosition -win $_nWave2 {("G1" 2)}
wvSetPosition -win $_nWave2 {("G1" 3)}
wvSetPosition -win $_nWave2 {("G1" 3)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
}
wvSelectSignal -win $_nWave2 {( "G1" 3 )} 
wvSetPosition -win $_nWave2 {("G1" 3)}
wvGetSignalClose -win $_nWave2
wvSetPosition -win $_nWave2 {("G1" 9)}
wvSetPosition -win $_nWave2 {("G2" 0)}
wvSetPosition -win $_nWave2 {("G1" 9)}
wvSetPosition -win $_nWave2 {("G1" 8)}
wvSetPosition -win $_nWave2 {("G1" 9)}
wvSetPosition -win $_nWave2 {("G2" 0)}
wvMoveSelected -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 1)}
wvSetPosition -win $_nWave2 {("G2" 1)}
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetSignalFilter -win $_nWave2 "*rvalid*"
wvSetPosition -win $_nWave2 {("G2" 1)}
wvSetPosition -win $_nWave2 {("G2" 1)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSetPosition -win $_nWave2 {("G2" 1)}
wvSetPosition -win $_nWave2 {("G2" 2)}
wvSetPosition -win $_nWave2 {("G2" 2)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSelectSignal -win $_nWave2 {( "G2" 2 )} 
wvSetPosition -win $_nWave2 {("G2" 2)}
wvGetSignalClose -win $_nWave2
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetSignalFilter -win $_nWave2 "*rready*"
wvSetPosition -win $_nWave2 {("G2" 2)}
wvSetPosition -win $_nWave2 {("G2" 2)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSetPosition -win $_nWave2 {("G2" 2)}
wvSetPosition -win $_nWave2 {("G2" 3)}
wvSetPosition -win $_nWave2 {("G2" 3)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSelectSignal -win $_nWave2 {( "G2" 3 )} 
wvSetPosition -win $_nWave2 {("G2" 3)}
wvGetSignalClose -win $_nWave2
wvSetCursor -win $_nWave2 3748142.837427 -snap {("G3" 0)}
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo"
wvSetPosition -win $_nWave2 {("G2" 3)}
wvSetPosition -win $_nWave2 {("G2" 3)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSetPosition -win $_nWave2 {("G2" 3)}
wvGetSignalSetSignalFilter -win $_nWave2 "*rready*"
wvGetSignalSetSignalFilter -win $_nWave2 "*"
wvSetPosition -win $_nWave2 {("G2" 3)}
wvSetPosition -win $_nWave2 {("G2" 3)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSetPosition -win $_nWave2 {("G2" 3)}
wvSetPosition -win $_nWave2 {("G2" 5)}
wvSetPosition -win $_nWave2 {("G2" 5)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSelectSignal -win $_nWave2 {( "G2" 4 5 )} 
wvSetPosition -win $_nWave2 {("G2" 5)}
wvGetSignalClose -win $_nWave2
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo"
wvSetPosition -win $_nWave2 {("G2" 6)}
wvSetPosition -win $_nWave2 {("G2" 6)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSelectSignal -win $_nWave2 {( "G2" 6 )} 
wvSetPosition -win $_nWave2 {("G2" 6)}
wvGetSignalClose -win $_nWave2
wvSetCursor -win $_nWave2 3774181.850160 -snap {("G2" 6)}
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo"
wvSetPosition -win $_nWave2 {("G2" 7)}
wvSetPosition -win $_nWave2 {("G2" 7)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSelectSignal -win $_nWave2 {( "G2" 7 )} 
wvSetPosition -win $_nWave2 {("G2" 7)}
wvGetSignalClose -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomOut -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G1" 8 )} 
wvSetCursor -win $_nWave2 3764991.610371 -snap {("G1" 8)}
wvSelectSignal -win $_nWave2 {( "G2" 4 )} 
wvSelectSignal -win $_nWave2 {( "G2" 1 )} 
wvSelectSignal -win $_nWave2 {( "G2" 7 )} 
wvSelectSignal -win $_nWave2 {( "G2" 6 )} 
wvSelectSignal -win $_nWave2 {( "G2" 7 )} 
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo"
wvSetPosition -win $_nWave2 {("G2" 8)}
wvSetPosition -win $_nWave2 {("G2" 8)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSelectSignal -win $_nWave2 {( "G2" 8 )} 
wvSetPosition -win $_nWave2 {("G2" 8)}
wvGetSignalClose -win $_nWave2
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic"
wvSetPosition -win $_nWave2 {("G2" 10)}
wvSetPosition -win $_nWave2 {("G2" 10)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSelectSignal -win $_nWave2 {( "G2" 9 10 )} 
wvSetPosition -win $_nWave2 {("G2" 10)}
wvGetSignalClose -win $_nWave2
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic"
wvSetPosition -win $_nWave2 {("G2" 11)}
wvSetPosition -win $_nWave2 {("G2" 11)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSelectSignal -win $_nWave2 {( "G2" 11 )} 
wvSetPosition -win $_nWave2 {("G2" 11)}
wvGetSignalClose -win $_nWave2
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic"
wvSetPosition -win $_nWave2 {("G2" 12)}
wvSetPosition -win $_nWave2 {("G2" 12)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSelectSignal -win $_nWave2 {( "G2" 12 )} 
wvSetPosition -win $_nWave2 {("G2" 12)}
wvGetSignalClose -win $_nWave2
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic"
wvSetPosition -win $_nWave2 {("G2" 13)}
wvSetPosition -win $_nWave2 {("G2" 13)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSelectSignal -win $_nWave2 {( "G2" 13 )} 
wvSetPosition -win $_nWave2 {("G2" 13)}
wvGetSignalClose -win $_nWave2
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axfsm_wr"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axfsm_rd"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvGetSignalSetSignalFilter -win $_nWave2 "*reg_state*"
wvSetPosition -win $_nWave2 {("G2" 13)}
wvSetPosition -win $_nWave2 {("G2" 13)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSetPosition -win $_nWave2 {("G2" 13)}
wvSetPosition -win $_nWave2 {("G2" 14)}
wvSetPosition -win $_nWave2 {("G2" 14)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSelectSignal -win $_nWave2 {( "G2" 14 )} 
wvSetPosition -win $_nWave2 {("G2" 14)}
wvGetSignalClose -win $_nWave2
wvSetCursor -win $_nWave2 3751763.234918 -snap {("G3" 0)}
wvZoomAll -win $_nWave2
wvZoom -win $_nWave2 0.000000 445974025.974026
wvZoom -win $_nWave2 0.000000 33882442.233092
wvZoom -win $_nWave2 0.000000 4994359.991501
wvZoom -win $_nWave2 3058234.722069 3226875.449054
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvGetSignalSetSignalFilter -win $_nWave2 "*reg_cmd*"
wvSetPosition -win $_nWave2 {("G2" 14)}
wvSetPosition -win $_nWave2 {("G2" 14)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSetPosition -win $_nWave2 {("G2" 14)}
wvGetSignalSetSignalFilter -win $_nWave2 "*reg_cnt_cmd*"
wvSetPosition -win $_nWave2 {("G2" 14)}
wvSetPosition -win $_nWave2 {("G2" 14)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSetPosition -win $_nWave2 {("G2" 14)}
wvSetPosition -win $_nWave2 {("G2" 15)}
wvSetPosition -win $_nWave2 {("G2" 15)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSelectSignal -win $_nWave2 {( "G2" 15 )} 
wvSetPosition -win $_nWave2 {("G2" 15)}
wvGetSignalClose -win $_nWave2
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSetCursor -win $_nWave2 3695346.247784 -snap {("G2" 15)}
wvGetSignalOpen -win $_nWave2
wvGetSignalSetSignalFilter -win $_nWave2 "*reg_cnt_addr*"
wvSetPosition -win $_nWave2 {("G2" 15)}
wvSetPosition -win $_nWave2 {("G2" 15)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSetPosition -win $_nWave2 {("G2" 15)}
wvSetPosition -win $_nWave2 {("G2" 16)}
wvSetPosition -win $_nWave2 {("G2" 16)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSelectSignal -win $_nWave2 {( "G2" 16 )} 
wvSetPosition -win $_nWave2 {("G2" 16)}
wvGetSignalClose -win $_nWave2
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSetCursor -win $_nWave2 3788208.154592 -snap {("G3" 0)}
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
debReload
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
verdiSetActWin -win $_nWave2
wvSetCursor -win $_nWave2 3797844.767563 -snap {("G2" 11)}
wvSetCursor -win $_nWave2 4273543.026021 -snap {("G2" 14)}
wvSelectSignal -win $_nWave2 {( "G2" 13 )} 
wvSelectSignal -win $_nWave2 {( "G2" 12 )} 
wvSetCursor -win $_nWave2 4292816.251962 -snap {("G2" 13)}
wvSetCursor -win $_nWave2 4284931.750441 -snap {("G2" 14)}
wvSetCursor -win $_nWave2 4305081.032107 -snap {("G2" 14)}
wvSetCursor -win $_nWave2 4287559.917615 -snap {("G2" 14)}
wvSetCursor -win $_nWave2 4294568.363412 -snap {("G2" 13)}
wvSetCursor -win $_nWave2 3514878.768516 -snap {("G2" 14)}
wvSelectSignal -win $_nWave2 {( "G2" 11 )} 
wvSelectSignal -win $_nWave2 {( "G2" 10 )} 
wvSelectSignal -win $_nWave2 {( "G2" 12 )} 
wvSelectSignal -win $_nWave2 {( "G2" 13 )} 
wvSelectSignal -win $_nWave2 {( "G2" 12 )} 
wvSetCursor -win $_nWave2 4292816.251962 -snap {("G2" 13)}
wvSetCursor -win $_nWave2 4312965.533628 -snap {("G2" 13)}
wvSetCursor -win $_nWave2 4291940.196237 -snap {("G2" 13)}
wvGetSignalOpen -win $_nWave2
wvGetSignalSetSignalFilter -win $_nWave2 "*i_ax_we*"
wvSetPosition -win $_nWave2 {("G2" 16)}
wvSetPosition -win $_nWave2 {("G2" 16)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSetPosition -win $_nWave2 {("G2" 16)}
wvSetPosition -win $_nWave2 {("G2" 17)}
wvSetPosition -win $_nWave2 {("G2" 17)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
}
wvSelectSignal -win $_nWave2 {( "G2" 17 )} 
wvSetPosition -win $_nWave2 {("G2" 17)}
wvGetSignalClose -win $_nWave2
wvSetCursor -win $_nWave2 4280551.471818 -snap {("G2" 14)}
wvSetCursor -win $_nWave2 4303328.920657 -snap {("G2" 14)}
wvSetCursor -win $_nWave2 4277923.304644 -snap {("G2" 14)}
wvSetCursor -win $_nWave2 4285807.806165 -snap {("G2" 14)}
wvSetCursor -win $_nWave2 4303328.920657 -snap {("G2" 14)}
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvGetSignalSetSignalFilter -win $_nWave2 "*qspi*"
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvZoomAll -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoom -win $_nWave2 7483437.500000 8249830.357143
wvSetCursor -win $_nWave2 4283037.471472 -snap {("G2" 14)}
wvSetCursor -win $_nWave2 4305929.725647 -snap {("G2" 14)}
wvGetSignalOpen -win $_nWave2
wvSetPosition -win $_nWave2 {("G3" 0)}
wvAddSignal -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]" \
           "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n" \
           "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]" \
           "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]"
wvSetPosition -win $_nWave2 {("G3" 0)}
wvSetPosition -win $_nWave2 {("G3" 4)}
wvSetPosition -win $_nWave2 {("G3" 4)}
wvScrollDown -win $_nWave2 1
wvSelectSignal -win $_nWave2 {( "G3" 1 )} 
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvSelectSignal -win $_nWave2 {( "G3" 2 )} 
wvSetCursor -win $_nWave2 4276070.263680 -snap {("G3" 2)}
wvSetCursor -win $_nWave2 3513092.525428 -snap {("G2" 14)}
wvSetCursor -win $_nWave2 3524141.439489 -snap {("G2" 14)}
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G3" 1 )} 
verdiWindowResize -win $_Verdi_1 "0" "0" "1604" "760"
verdiDockWidgetRestore -dock windowDock_nWave_2
wvScrollDown -win $_nWave2 5
wvScrollDown -win $_nWave2 2
wvScrollDown -win $_nWave2 3
wvScrollDown -win $_nWave2 10
srcTraceConnectivity "test_top.u_dut_wrapper.u_dut.u_qspi_fsm.i_qspi_si\[3:0\]" \
           -win $_nTrace1
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
verdiSetActWin -dock widgetDock_<Inst._Tree>
srcHBSelect "test_top.u_dut_wrapper.u_psram" -win $_nTrace1
srcHBSelect "test_top.u_dut_wrapper.u_psram" -win $_nTrace1
srcHBSelect "test_top.u_dut_wrapper.u_psram" -win $_nTrace1
srcHBSelect "test_top.u_dut_wrapper.u_dut" -win $_nTrace1
srcHBSelect "test_top.u_dut_wrapper" -win $_nTrace1
srcHBSelect "test_top.u_dut_wrapper" -win $_nTrace1
srcSetScope "test_top.u_dut_wrapper" -delim "." -win $_nTrace1
srcHBSelect "test_top.u_dut_wrapper" -win $_nTrace1
wvSetPosition -win $_nWave2 {("G3" 1)}
wvSetPosition -win $_nWave2 {("G3" 4)}
verdiSetActWin -win $_nWave2
srcTraceConnectivity "test_top.u_dut_wrapper.u_dut.u_qspi_fsm.i_qspi_si\[3:0\]" \
           -win $_nTrace1
wvSetPosition -win $_nWave2 {("G2" 16)}
wvSetPosition -win $_nWave2 {("G3" 0)}
wvSetPosition -win $_nWave2 {("G2" 16)}
wvSetPosition -win $_nWave2 {("G3" 4)}
srcTraceConnectivity "test_top.u_dut_wrapper.u_dut.u_qspi_fsm.i_qspi_si\[3:0\]" \
           -win $_nTrace1
wvSetPosition -win $_nWave2 {("G2" 14)}
wvSetPosition -win $_nWave2 {("G3" 0)}
wvSetPosition -win $_nWave2 {("G2" 14)}
wvSetPosition -win $_nWave2 {("G3" 4)}
srcTraceConnectivity "test_top.u_dut_wrapper.u_dut.u_qspi_fsm.i_qspi_si\[3:0\]" \
           -win $_nTrace1
srcDeselectAll -win $_nTrace1
srcAction -pos 165 5 3 -win $_nTrace1 -name "qspi_si" -ctrlKey off
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
wvDrop -win $_nWave2
srcDeselectAll -win $_nTrace1
srcHBSelect "test_top.u_dut_wrapper.u_psram" -win $_nTrace1
verdiSetActWin -dock widgetDock_<Inst._Tree>
srcHBDrag -win $_nTrace1
srcSetScope "test_top.u_dut_wrapper.u_psram" -delim "." -win $_nTrace1
verdiSetActWin -win $_nWave2
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
verdiDockWidgetMaximize -dock windowDock_nWave_2
wvZoom -win $_nWave2 2925491.186728 3170576.189537
wvSetCursor -win $_nWave2 3115511.636957 -snap {("G2" 14)}
wvSetCursor -win $_nWave2 3124105.526666 -snap {("G2" 14)}
wvSelectSignal -win $_nWave2 {( "G2" 17 )} 
wvGetSignalOpen -win $_nWave2
wvGetSignalSetSignalFilter -win $_nWave2 "*ax*"
wvSetPosition -win $_nWave2 {("G3" 4)}
wvSetPosition -win $_nWave2 {("G3" 4)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSetPosition -win $_nWave2 {("G3" 4)}
wvSetPosition -win $_nWave2 {("G3" 5)}
wvSetPosition -win $_nWave2 {("G3" 5)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSelectSignal -win $_nWave2 {( "G3" 5 )} 
wvSetPosition -win $_nWave2 {("G3" 5)}
wvGetSignalClose -win $_nWave2
wvSetPosition -win $_nWave2 {("G3" 3)}
wvSetPosition -win $_nWave2 {("G3" 2)}
wvSetPosition -win $_nWave2 {("G2" 17)}
wvMoveSelected -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 17)}
wvSetPosition -win $_nWave2 {("G2" 18)}
wvSelectSignal -win $_nWave2 {( "G2" 17 )} 
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G2" 18 )} 
wvGetSignalOpen -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G2" 13 )} 
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvZoom -win $_nWave2 3115193.344746 3138587.822287
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G2" 17 )} 
wvScrollDown -win $_nWave2 0
wvSelectSignal -win $_nWave2 {( "G2" 5 )} 
wvSetPosition -win $_nWave2 {("G2" 6)}
wvSetPosition -win $_nWave2 {("G2" 5)}
wvSetPosition -win $_nWave2 {("G2" 6)}
wvSetPosition -win $_nWave2 {("G2" 7)}
wvSetPosition -win $_nWave2 {("G2" 8)}
wvSetPosition -win $_nWave2 {("G2" 9)}
wvSetPosition -win $_nWave2 {("G2" 12)}
wvSetPosition -win $_nWave2 {("G2" 13)}
wvSetPosition -win $_nWave2 {("G2" 15)}
wvSetPosition -win $_nWave2 {("G2" 16)}
wvSetPosition -win $_nWave2 {("G2" 17)}
wvSetPosition -win $_nWave2 {("G2" 18)}
wvMoveSelected -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 18)}
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G2" 10 )} 
wvSelectSignal -win $_nWave2 {( "G2" 16 )} 
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvScrollDown -win $_nWave2 0
wvSelectSignal -win $_nWave2 {( "G2" 16 )} 
wvSelectSignal -win $_nWave2 {( "G2" 16 )} 
wvZoom -win $_nWave2 3426137.532274 3568405.390451
wvSetCursor -win $_nWave2 3505195.948875 -snap {("G2" 16)}
wvSetCursor -win $_nWave2 3515357.938744 -snap {("G2" 16)}
wvSetCursor -win $_nWave2 3505289.178140 -snap {("G2" 17)}
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G3" 3 )} 
wvSelectSignal -win $_nWave2 {( "G3" 4 )} 
wvGetSignalOpen -win $_nWave2
wvGetSignalSetSignalFilter -win $_nWave2 "*reg_data*"
wvSetPosition -win $_nWave2 {("G2" 18)}
wvSetPosition -win $_nWave2 {("G2" 18)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSetPosition -win $_nWave2 {("G2" 18)}
wvSetPosition -win $_nWave2 {("G2" 19)}
wvSetPosition -win $_nWave2 {("G2" 19)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetPosition -win $_nWave2 {("G2" 19)}
wvGetSignalClose -win $_nWave2
wvScrollDown -win $_nWave2 0
wvSetCursor -win $_nWave2 3738227.505430 -snap {("G2" 19)}
wvZoomAll -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G3" 2 )} 
wvZoom -win $_nWave2 2898210.222805 4358636.467890
wvScrollDown -win $_nWave2 0
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvZoom -win $_nWave2 3421705.082608 3705942.693873
wvSelectSignal -win $_nWave2 {( "G3" 4 )} 
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G3" 3 )} 
wvSelectSignal -win $_nWave2 {( "G3" 4 )} 
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvSelectSignal -win $_nWave2 {( "G3" 4 )} 
wvSetPosition -win $_nWave2 {("G3" 4)}
wvExpandBus -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G3" 5 )} 
wvSelectSignal -win $_nWave2 {( "G3" 5 )} 
wvSelectSignal -win $_nWave2 {( "G3" 5 )} 
wvSelectSignal -win $_nWave2 {( "G3" 6 )} 
wvSelectSignal -win $_nWave2 {( "G3" 5 )} 
wvSelectSignal -win $_nWave2 {( "G3" 4 )} 
wvSetPosition -win $_nWave2 {("G3" 4)}
wvCollapseBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G3" 4)}
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetPosition -win $_nWave2 {("G2" 19)}
wvExpandBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G3" 4)}
wvScrollUp -win $_nWave2 5
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetPosition -win $_nWave2 {("G2" 19)}
wvCollapseBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 19)}
wvSetPosition -win $_nWave2 {("G3" 4)}
wvSetCursor -win $_nWave2 3524879.644100 -snap {("G2" 19)}
wvGetSignalOpen -win $_nWave2
wvGetSignalSetSignalFilter -win $_nWave2 "*reg_ax_addr*"
wvSetPosition -win $_nWave2 {("G3" 4)}
wvSetPosition -win $_nWave2 {("G3" 4)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSetPosition -win $_nWave2 {("G3" 4)}
wvSetPosition -win $_nWave2 {("G3" 5)}
wvSetPosition -win $_nWave2 {("G3" 5)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSelectSignal -win $_nWave2 {( "G3" 5 )} 
wvSetPosition -win $_nWave2 {("G3" 5)}
wvGetSignalClose -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetPosition -win $_nWave2 {("G2" 19)}
wvExpandBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G3" 5)}
wvScrollUp -win $_nWave2 2
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetPosition -win $_nWave2 {("G2" 19)}
wvCollapseBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 19)}
wvSetPosition -win $_nWave2 {("G3" 5)}
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvGetSignalSetSignalFilter -win $_nWave2 "*csr*"
wvSetPosition -win $_nWave2 {("G3" 5)}
wvSetPosition -win $_nWave2 {("G3" 5)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSetPosition -win $_nWave2 {("G3" 5)}
wvSetPosition -win $_nWave2 {("G3" 6)}
wvSetPosition -win $_nWave2 {("G3" 6)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSelectSignal -win $_nWave2 {( "G3" 6 )} 
wvSetPosition -win $_nWave2 {("G3" 6)}
wvGetSignalClose -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G3" 6 )} 
wvSetRadix -win $_nWave2 -format UDec
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvScrollDown -win $_nWave2 0
wvSelectSignal -win $_nWave2 {( "G3" 5 )} 
wvSelectSignal -win $_nWave2 {( "G3" 3 )} 
wvSelectSignal -win $_nWave2 {( "G3" 4 )} 
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSelectSignal -win $_nWave2 {( "G3" 6 )} 
wvSelectSignal -win $_nWave2 {( "G3" 6 )} 
wvExpandBus -win $_nWave2
wvScrollDown -win $_nWave2 1
wvSelectSignal -win $_nWave2 {( "G3" 6 )} 
wvSelectSignal -win $_nWave2 {( "G3" 6 )} 
wvSetPosition -win $_nWave2 {("G3" 6)}
wvCollapseBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G3" 6)}
wvSelectSignal -win $_nWave2 {( "G3" 5 )} 
wvSetPosition -win $_nWave2 {("G3" 5)}
wvExpandBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G3" 38)}
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSelectSignal -win $_nWave2 {( "G3" 5 )} 
wvSetPosition -win $_nWave2 {("G3" 5)}
wvCollapseBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G3" 5)}
wvSetPosition -win $_nWave2 {("G3" 6)}
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetPosition -win $_nWave2 {("G2" 19)}
wvExpandBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G3" 6)}
wvScrollUp -win $_nWave2 3
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetPosition -win $_nWave2 {("G2" 19)}
wvCollapseBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 19)}
wvSetPosition -win $_nWave2 {("G3" 6)}
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetPosition -win $_nWave2 {("G2" 19)}
wvExpandBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G3" 6)}
wvScrollUp -win $_nWave2 10
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetPosition -win $_nWave2 {("G2" 19)}
wvCollapseBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 19)}
wvSetPosition -win $_nWave2 {("G3" 6)}
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSetCursor -win $_nWave2 3542413.782457 -snap {("G2" 11)}
wvZoom -win $_nWave2 5251830.399706 5336580.146184
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G3" 4 )} 
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetCursor -win $_nWave2 5267239.444520 -snap {("G2" 18)}
wvZoomAll -win $_nWave2
wvZoom -win $_nWave2 2252905.602883 5173758.093054
wvZoom -win $_nWave2 3175481.553251 3799464.457442
wvZoom -win $_nWave2 3424502.253547 3732813.596772
wvGetSignalOpen -win $_nWave2
wvSetPosition -win $_nWave2 {("G3" 7)}
wvSetPosition -win $_nWave2 {("G3" 7)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSelectSignal -win $_nWave2 {( "G3" 7 )} 
wvSetPosition -win $_nWave2 {("G3" 7)}
wvGetSignalClose -win $_nWave2
wvSetPosition -win $_nWave2 {("G3" 6)}
wvSetPosition -win $_nWave2 {("G3" 3)}
wvSetPosition -win $_nWave2 {("G3" 2)}
wvSetPosition -win $_nWave2 {("G3" 0)}
wvSetPosition -win $_nWave2 {("G2" 19)}
wvMoveSelected -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 19)}
wvSetPosition -win $_nWave2 {("G2" 20)}
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetPosition -win $_nWave2 {("G2" 19)}
wvExpandBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 53)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSelectSignal -win $_nWave2 {( "G2" 20 )} 
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetPosition -win $_nWave2 {("G2" 19)}
wvCollapseBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 19)}
wvSetPosition -win $_nWave2 {("G2" 20)}
wvScrollDown -win $_nWave2 0
wvSelectSignal -win $_nWave2 {( "G2" 20 )} 
wvSelectSignal -win $_nWave2 {( "G2" 20 )} 
wvExpandBus -win $_nWave2
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvSelectSignal -win $_nWave2 {( "G2" 20 )} 
wvSelectSignal -win $_nWave2 {( "G2" 20 )} 
wvSetPosition -win $_nWave2 {("G2" 20)}
wvCollapseBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 20)}
wvSelectSignal -win $_nWave2 {( "G2" 18 )} 
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetPosition -win $_nWave2 {("G2" 19)}
wvExpandBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 53)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSetCursor -win $_nWave2 3525464.506766 -snap {("G2" 19)}
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetPosition -win $_nWave2 {("G2" 19)}
wvCollapseBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 19)}
wvSetPosition -win $_nWave2 {("G2" 20)}
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetPosition -win $_nWave2 {("G2" 19)}
wvExpandBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 53)}
wvScrollUp -win $_nWave2 1
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetPosition -win $_nWave2 {("G2" 19)}
wvCollapseBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 19)}
wvSetPosition -win $_nWave2 {("G2" 20)}
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G3" 4 )} 
wvSetCursor -win $_nWave2 3534016.124108 -snap {("G2" 19)}
wvSetCursor -win $_nWave2 3525206.861017 -snap {("G2" 19)}
wvSetCursor -win $_nWave2 3535217.387256 -snap {("G2" 19)}
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetPosition -win $_nWave2 {("G2" 19)}
wvExpandBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 53)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetPosition -win $_nWave2 {("G2" 19)}
wvCollapseBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 19)}
wvSetPosition -win $_nWave2 {("G2" 20)}
wvSetCursor -win $_nWave2 3525006.650493 -snap {("G2" 19)}
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvScrollDown -win $_nWave2 0
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
debReload
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetPosition -win $_nWave2 {("G2" 19)}
wvExpandBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 53)}
verdiSetActWin -win $_nWave2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetPosition -win $_nWave2 {("G2" 19)}
wvCollapseBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 19)}
wvSetPosition -win $_nWave2 {("G2" 20)}
wvSetCursor -win $_nWave2 3535367.748340 -snap {("G2" 19)}
wvSetCursor -win $_nWave2 3544462.562030 -snap {("G2" 19)}
wvSelectSignal -win $_nWave2 {( "G3" 4 )} 
wvSelectSignal -win $_nWave2 {( "G3" 4 )} 
wvSelectSignal -win $_nWave2 {( "G3" 4 )} 
wvSetPosition -win $_nWave2 {("G3" 4)}
wvExpandBus -win $_nWave2
wvScrollDown -win $_nWave2 1
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetPosition -win $_nWave2 {("G2" 19)}
wvExpandBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G3" 8)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSelectSignal -win $_nWave2 {( "G2" 21 22 23 24 25 26 27 28 29 30 31 32 33 34 \
           35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 )} 
wvSelectSignal -win $_nWave2 {( "G2" 22 23 24 25 26 27 28 29 30 31 32 33 34 35 \
           36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 )} 
wvSelectSignal -win $_nWave2 {( "G2" 23 24 25 26 27 28 29 30 31 32 33 34 35 36 \
           37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 )} 
wvSelectSignal -win $_nWave2 {( "G2" 24 25 26 27 28 29 30 31 32 33 34 35 36 37 \
           38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 )} 
wvCut -win $_nWave2
wvSetPosition -win $_nWave2 {("G3" 8)}
wvSetCursor -win $_nWave2 3525464.506767 -snap {("G2" 19)}
wvSetCursor -win $_nWave2 3534155.106515 -snap {("G2" 19)}
wvSetCursor -win $_nWave2 3524251.864942 -snap {("G2" 19)}
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G3" 3 )} 
wvSetCursor -win $_nWave2 3685108.803069 -snap {("G2" 14)}
wvSetCursor -win $_nWave2 3525242.189099 -snap {("G2" 14)}
wvSetCursor -win $_nWave2 3535145.430672 -snap {("G2" 14)}
wvSetCursor -win $_nWave2 3525444.296070 -snap {("G2" 13)}
wvSelectSignal -win $_nWave2 {( "G2" 14 )} 
wvSelectSignal -win $_nWave2 {( "G3" 10 )} 
wvGetSignalOpen -win $_nWave2
wvSetPosition -win $_nWave2 {("G3" 9)}
wvSetPosition -win $_nWave2 {("G3" 9)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSelectSignal -win $_nWave2 {( "G3" 9 )} 
wvSetPosition -win $_nWave2 {("G3" 9)}
wvGetSignalClose -win $_nWave2
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G2" 15 )} 
wvSelectSignal -win $_nWave2 {( "G2" 15 )} 
wvSetRadix -win $_nWave2 -format UDec
wvSetCursor -win $_nWave2 3925777.783998 -snap {("G2" 15)}
wvSelectSignal -win $_nWave2 {( "G3" 9 )} 
wvSelectSignal -win $_nWave2 {( "G3" 10 )} 
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSetCursor -win $_nWave2 3525331.857090 -snap {("G2" 14)}
wvSetCursor -win $_nWave2 3534426.670780 -snap {("G2" 14)}
wvSetCursor -win $_nWave2 3685602.685002 -snap {("G2" 14)}
wvGetSignalOpen -win $_nWave2
wvSetPosition -win $_nWave2 {("G3" 10)}
wvSetPosition -win $_nWave2 {("G3" 10)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSelectSignal -win $_nWave2 {( "G3" 10 )} 
wvSetPosition -win $_nWave2 {("G3" 10)}
wvGetSignalClose -win $_nWave2
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_csr"
wvGetSignalSetSignalFilter -win $_nWave2 "*mode*"
wvSetPosition -win $_nWave2 {("G3" 10)}
wvSetPosition -win $_nWave2 {("G3" 10)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSetPosition -win $_nWave2 {("G3" 10)}
wvSetPosition -win $_nWave2 {("G3" 11)}
wvSetPosition -win $_nWave2 {("G3" 11)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSelectSignal -win $_nWave2 {( "G3" 11 )} 
wvSetPosition -win $_nWave2 {("G3" 11)}
wvGetSignalClose -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoom -win $_nWave2 3185468.774851 4013298.927595
wvZoom -win $_nWave2 3517609.018813 3700762.239346
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvScrollDown -win $_nWave2 0
wvSelectSignal -win $_nWave2 {( "G3" 2 )} 
wvSetCursor -win $_nWave2 3523928.920197 -snap {("G3" 2)}
wvSelectSignal -win $_nWave2 {( "G3" 4 )} 
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G3" 3 )} 
wvSetCursor -win $_nWave2 3683821.794015 -snap {("G3" 3)}
wvSelectSignal -win $_nWave2 {( "G2" 22 )} 
wvSelectSignal -win $_nWave2 {( "G2" 21 )} 
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetCursor -win $_nWave2 3526693.025730 -snap {("G2" 13)}
wvGetSignalOpen -win $_nWave2
wvGetSignalSetSignalFilter -win $_nWave2 "*csr_in"
wvSetPosition -win $_nWave2 {("G3" 11)}
wvSetPosition -win $_nWave2 {("G3" 11)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSetPosition -win $_nWave2 {("G3" 11)}
wvGetSignalSetSignalFilter -win $_nWave2 "*csr_in*"
wvSetPosition -win $_nWave2 {("G3" 11)}
wvSetPosition -win $_nWave2 {("G3" 11)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSetPosition -win $_nWave2 {("G3" 11)}
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvSetPosition -win $_nWave2 {("G3" 12)}
wvSetPosition -win $_nWave2 {("G3" 12)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSelectSignal -win $_nWave2 {( "G3" 12 )} 
wvSetPosition -win $_nWave2 {("G3" 12)}
wvGetSignalClose -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetCursor -win $_nWave2 3744218.164325 -snap {("G2" 19)}
wvSetCursor -win $_nWave2 3523255.833923 -snap {("G2" 13)}
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvGetSignalSetSignalFilter -win $_nWave2 "*csr_c*"
wvSetPosition -win $_nWave2 {("G3" 12)}
wvSetPosition -win $_nWave2 {("G3" 12)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSetPosition -win $_nWave2 {("G3" 12)}
wvSetPosition -win $_nWave2 {("G3" 13)}
wvSetPosition -win $_nWave2 {("G3" 13)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSelectSignal -win $_nWave2 {( "G3" 13 )} 
wvSetPosition -win $_nWave2 {("G3" 13)}
wvGetSignalClose -win $_nWave2
wvSetCursor -win $_nWave2 3516381.450311 -snap {("G3" 12)}
wvSetCursor -win $_nWave2 3525219.943527 -snap {("G2" 13)}
wvSelectSignal -win $_nWave2 {( "G2" 23 )} 
verdiWindowResize -win $_Verdi_1 "0" "0" "1604" "760"
verdiDockWidgetRestore -dock windowDock_nWave_2
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetPosition -win $_nWave2 {("G2" 16)}
wvSetPosition -win $_nWave2 {("G3" 13)}
srcTraceConnectivity \
           "test_top.u_dut_wrapper.u_dut.u_qspi_fsm.reg_data_out\[32:0\]" -win \
           $_nTrace1
wvSelectSignal -win $_nWave2 {( "G2" 15 )} 
wvSaveSignal -win $_nWave2 "/home/ltthinh/PSRAM_CTRL/sim/vcs/signal.rc"
debReload
wvSelectSignal -win $_nWave2 {( "G2" 15 )} 
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetPosition -win $_nWave2 {("G2" 18)}
wvSetPosition -win $_nWave2 {("G3" 13)}
srcTraceConnectivity \
           "test_top.u_dut_wrapper.u_dut.u_qspi_fsm.reg_data_out\[32:0\]" -win \
           $_nTrace1
wvSetCursor -win $_nWave2 3745200.219127 -snap {("G2" 14)}
wvSetCursor -win $_nWave2 3526693.025730 -snap {("G2" 14)}
srcDeselectAll -win $_nTrace1
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
srcSetOptions -annotate on -win $_nTrace1
schSetOptions -win $_nSchema1 -annotate on
wvSetPosition -win $_nWave2 {("G2" 19)}
wvSetPosition -win $_nWave2 {("G2" 18)}
wvSetPosition -win $_nWave2 {("G3" 13)}
wvSetPosition -win $_nWave2 {("G2" 10)}
verdiSetActWin -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 9)}
wvSetPosition -win $_nWave2 {("G3" 13)}
srcTraceConnectivity \
           "test_top.u_dut_wrapper.u_dut.u_qspi_fsm.reg_data_out\[32:0\]" -win \
           $_nTrace1
wvScrollDown -win $_nWave2 1
wvSetPosition -win $_nWave2 {("G2" 15)}
wvSetPosition -win $_nWave2 {("G2" 18)}
wvSetPosition -win $_nWave2 {("G2" 15)}
wvSetPosition -win $_nWave2 {("G3" 13)}
srcTraceConnectivity \
           "test_top.u_dut_wrapper.u_dut.u_qspi_fsm.reg_data_out\[32:0\]" -win \
           $_nTrace1
wvSetCursor -win $_nWave2 3525911.634358 -snap {("G2" 14)}
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvGetSignalOpen -win $_nWave2
wvGetSignalSetSignalFilter -win $_nWave2 "*csr*"
wvSetPosition -win $_nWave2 {("G3" 13)}
wvSetPosition -win $_nWave2 {("G3" 13)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSetPosition -win $_nWave2 {("G3" 13)}
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvSetPosition -win $_nWave2 {("G3" 8)}
wvSetPosition -win $_nWave2 {("G3" 13)}
wvSetPosition -win $_nWave2 {("G3" 9)}
wvSetPosition -win $_nWave2 {("G3" 10)}
wvSetPosition -win $_nWave2 {("G3" 11)}
wvSetPosition -win $_nWave2 {("G3" 12)}
wvSetPosition -win $_nWave2 {("G3" 13)}
wvSetPosition -win $_nWave2 {("G3" 11)}
wvAddSignal -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_independent_cmd\[15:0\]"
wvSetPosition -win $_nWave2 {("G3" 11)}
wvSetPosition -win $_nWave2 {("G3" 12)}
wvSetPosition -win $_nWave2 {("G3" 12)}
wvSetPosition -win $_nWave2 {("G3" 12)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSetPosition -win $_nWave2 {("G3" 12)}
wvGetSignalClose -win $_nWave2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSelectSignal -win $_nWave2 {( "G3" 12 )} 
wvSetCursor -win $_nWave2 3693450.980881 -snap {("G3" 12)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvSetCursor -win $_nWave2 3515998.063558 -snap {("G3" 13)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
verdiDockWidgetMaximize -dock windowDock_nWave_2
wvSetCursor -win $_nWave2 3524424.598738 -snap {("G2" 13)}
wvSelectSignal -win $_nWave2 {( "G3" 14 )} 
wvSelectSignal -win $_nWave2 {( "G3" 13 )} 
wvSetCursor -win $_nWave2 3513519.670858 -snap {("G3" 13)}
wvZoomOut -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G3" 8 )} 
wvSelectSignal -win $_nWave2 {( "G3" 7 )} 
wvSelectSignal -win $_nWave2 {( "G3" 9 )} 
wvSelectSignal -win $_nWave2 {( "G3" 10 )} 
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvSelectSignal -win $_nWave2 {( "G3" 15 )} 
wvScrollDown -win $_nWave2 0
wvSelectSignal -win $_nWave2 {( "G3" 13 )} 
wvSelectSignal -win $_nWave2 {( "G3" 11 )} 
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvSetPosition -win $_nWave2 {("G3" 14)}
wvSetPosition -win $_nWave2 {("G3" 14)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_req} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_independent_ack} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSelectSignal -win $_nWave2 {( "G3" 13 14 )} 
wvSetPosition -win $_nWave2 {("G3" 14)}
wvGetSignalClose -win $_nWave2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvZoom -win $_nWave2 3416961.491264 3628120.549307
wvSetCursor -win $_nWave2 3525112.646162 -snap {("G3" 13)}
wvSetCursor -win $_nWave2 3514540.406449 -snap {("G3" 13)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvSetCursor -win $_nWave2 3525112.646162 -snap {("G3" 13)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomIn -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G3" 12 )} 
wvSetCursor -win $_nWave2 3514540.406448 -snap {("G3" 13)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSetCursor -win $_nWave2 3524541.173744 -snap {("G1" 2)}
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvSetCursor -win $_nWave2 3517112.032324 -snap {("G3" 13)}
wvSelectSignal -win $_nWave2 {( "G3" 13 )} 
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSetCursor -win $_nWave2 3535278.496978 -snap {("G3" 13)}
wvSetCursor -win $_nWave2 3545185.423293 -snap {("G3" 14)}
wvSetCursor -win $_nWave2 3534995.441940 -snap {("G2" 13)}
wvSetCursor -win $_nWave2 3523956.295474 -snap {("G3" 14)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvSelectSignal -win $_nWave2 {( "G3" 13 )} 
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSetCursor -win $_nWave2 3536127.662090 -snap {("G1" 2)}
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvSetCursor -win $_nWave2 3546034.588406 -snap {("G2" 12)}
wvSetCursor -win $_nWave2 3534712.386902 -snap {("G3" 13)}
wvSetCursor -win $_nWave2 3543770.148105 -snap {("G3" 14)}
wvSetCursor -win $_nWave2 3535561.552015 -snap {("G3" 13)}
wvSetCursor -win $_nWave2 3524522.405549 -snap {("G3" 14)}
wvSelectSignal -win $_nWave2 {( "G3" 13 )} 
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G3" 10 )} 
wvSetCursor -win $_nWave2 3708612.439227 -snap {("G2" 20)}
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
verdiDockWidgetRestore -dock windowDock_nWave_2
wvScrollDown -win $_nWave2 6
wvScrollDown -win $_nWave2 10
wvSetPosition -win $_nWave2 {("G3" 0)}
wvSetPosition -win $_nWave2 {("G2" 24)}
wvSetPosition -win $_nWave2 {("G3" 14)}
srcTraceConnectivity \
           "test_top.u_dut_wrapper.u_dut.u_qspi_fsm.o_csr_mode_status_current\[1:0\]" \
           -win $_nTrace1
debReload
wvSelectSignal -win $_nWave2 {( "G3" 10 )} 
wvSetPosition -win $_nWave2 {("G3" 10)}
wvExpandBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G3" 16)}
wvSelectSignal -win $_nWave2 {( "G3" 11 )} 
wvSelectSignal -win $_nWave2 {( "G3" 9 )} 
wvSelectSignal -win $_nWave2 {( "G3" 10 )} 
wvSetPosition -win $_nWave2 {("G3" 7)}
wvSetPosition -win $_nWave2 {("G3" 16)}
srcTraceConnectivity \
           "test_top.u_dut_wrapper.u_dut.u_qspi_fsm.o_csr_mode_status_current\[1:0\]" \
           -win $_nTrace1
srcHBSelect "test_top.u_dut_wrapper.u_dut.u_csr" -win $_nTrace1
verdiSetActWin -dock widgetDock_<Inst._Tree>
srcHBSelect "test_top.u_dut_wrapper.u_dut.u_csr" -win $_nTrace1
srcSetScope "test_top.u_dut_wrapper.u_dut.u_csr" -delim "." -win $_nTrace1
srcHBSelect "test_top.u_dut_wrapper.u_dut.u_csr" -win $_nTrace1
verdiSetActWin -win $_nWave2
wvSetPosition -win $_nWave2 {("G3" 8)}
wvSetPosition -win $_nWave2 {("G3" 16)}
srcTraceConnectivity \
           "test_top.u_dut_wrapper.u_dut.u_qspi_fsm.o_csr_mode_status_current\[1:0\]" \
           -win $_nTrace1
srcDeselectAll -win $_nTrace1
srcSelect -signal "mode_status_value\[1:0\]" -line 483 -pos 1 -win $_nTrace1
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
srcDeselectAll -win $_nTrace1
srcSelect -signal "i_mode_status_current" -line 483 -pos 1 -win $_nTrace1
srcDeselectAll -win $_nTrace1
srcSelect -signal "reg_independent_mode" -line 523 -pos 1 -win $_nTrace1
srcDeselectAll -win $_nTrace1
srcSelect -signal "reg_independent_mode" -line 523 -pos 1 -win $_nTrace1
srcAction -pos 522 5 12 -win $_nTrace1 -name "reg_independent_mode" -ctrlKey off
srcDeselectAll -win $_nTrace1
srcSelect -signal "nxt_independent_mode" -line 503 -pos 1 -win $_nTrace1
srcDeselectAll -win $_nTrace1
srcSelect -signal "we_independent" -line 497 -pos 1 -win $_nTrace1
verdiSetActWin -win $_nWave2
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_wfifo"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_csr"
wvSetPosition -win $_nWave2 {("G3" 16)}
wvSetPosition -win $_nWave2 {("G3" 16)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_req} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_independent_ack} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSetPosition -win $_nWave2 {("G3" 16)}
wvGetSignalSetSignalFilter -win $_nWave2 "*csr_c*"
wvGetSignalSetSignalFilter -win $_nWave2 "*"
wvSetPosition -win $_nWave2 {("G3" 16)}
wvSetPosition -win $_nWave2 {("G3" 16)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_req} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_independent_ack} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSetPosition -win $_nWave2 {("G3" 16)}
wvScrollDown -win $_nWave2 0
wvSetPosition -win $_nWave2 {("G3" 24)}
wvSetPosition -win $_nWave2 {("G3" 24)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_req} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_independent_ack} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_paddr\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_psel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwrite} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSelectSignal -win $_nWave2 {( "G3" 21 22 23 24 )} 
wvSetPosition -win $_nWave2 {("G3" 24)}
wvGetSignalClose -win $_nWave2
wvSetCursor -win $_nWave2 3414825.569705 -snap {("G3" 21)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
verdiDockWidgetMaximize -dock windowDock_nWave_2
wvSelectSignal -win $_nWave2 {( "G3" 17 )} 
wvSelectSignal -win $_nWave2 {( "G3" 13 )} 
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvZoom -win $_nWave2 10316875.837802 11089133.210456
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvZoomAll -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G3" 22 )} 
wvSelectSignal -win $_nWave2 {( "G3" 23 )} 
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G3" 12 )} 
wvScrollUp -win $_nWave2 4
wvScrollUp -win $_nWave2 3
wvZoom -win $_nWave2 4681810.321716 8941292.392761
wvZoom -win $_nWave2 4961356.844646 5278368.365495
wvSetCursor -win $_nWave2 5074605.885923 -snap {("G2" 15)}
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSetCursor -win $_nWave2 5164482.189104 -snap {("G2" 19)}
wvSelectSignal -win $_nWave2 {( "G2" 15 )} 
wvSetCursor -win $_nWave2 5083529.515214 -snap {("G2" 15)}
wvGetSignalOpen -win $_nWave2
wvGetSignalSetSignalFilter -win $_nWave2 "*reg_cnt_data*"
wvSetPosition -win $_nWave2 {("G3" 24)}
wvSetPosition -win $_nWave2 {("G3" 24)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_req} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_independent_ack} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_paddr\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_psel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwrite} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSetPosition -win $_nWave2 {("G3" 24)}
wvGetSignalSetSignalFilter -win $_nWave2 "*reg_cnt_data*"
wvSetPosition -win $_nWave2 {("G3" 24)}
wvSetPosition -win $_nWave2 {("G3" 24)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_req} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_independent_ack} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_paddr\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_psel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwrite} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSetPosition -win $_nWave2 {("G3" 24)}
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvSetPosition -win $_nWave2 {("G3" 25)}
wvSetPosition -win $_nWave2 {("G3" 25)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_req} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_independent_ack} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_paddr\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_psel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwrite} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_data\[23:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSelectSignal -win $_nWave2 {( "G3" 25 )} 
wvSetPosition -win $_nWave2 {("G3" 25)}
wvGetSignalClose -win $_nWave2
wvSetPosition -win $_nWave2 {("G3" 11)}
wvSetPosition -win $_nWave2 {("G3" 10)}
wvSetPosition -win $_nWave2 {("G3" 9)}
wvSetPosition -win $_nWave2 {("G3" 25)}
wvSetPosition -win $_nWave2 {("G2" 20)}
wvSetPosition -win $_nWave2 {("G2" 19)}
wvSetPosition -win $_nWave2 {("G2" 18)}
wvSetPosition -win $_nWave2 {("G2" 19)}
wvSetPosition -win $_nWave2 {("G3" 2)}
wvSetPosition -win $_nWave2 {("G2" 24)}
wvSetPosition -win $_nWave2 {("G2" 19)}
wvSetPosition -win $_nWave2 {("G3" 25)}
wvSetPosition -win $_nWave2 {("G2" 17)}
wvSetPosition -win $_nWave2 {("G2" 16)}
wvSetPosition -win $_nWave2 {("G2" 15)}
wvSetPosition -win $_nWave2 {("G2" 14)}
wvSetPosition -win $_nWave2 {("G2" 13)}
wvSetPosition -win $_nWave2 {("G2" 12)}
wvSetPosition -win $_nWave2 {("G2" 11)}
wvSetPosition -win $_nWave2 {("G2" 10)}
wvSetPosition -win $_nWave2 {("G2" 9)}
wvSetPosition -win $_nWave2 {("G2" 8)}
wvSetPosition -win $_nWave2 {("G2" 7)}
wvSetPosition -win $_nWave2 {("G2" 6)}
wvSetPosition -win $_nWave2 {("G2" 5)}
wvSetPosition -win $_nWave2 {("G2" 6)}
wvSetPosition -win $_nWave2 {("G2" 8)}
wvSetPosition -win $_nWave2 {("G2" 9)}
wvSetPosition -win $_nWave2 {("G2" 10)}
wvSetPosition -win $_nWave2 {("G2" 11)}
wvSetPosition -win $_nWave2 {("G2" 12)}
wvSetPosition -win $_nWave2 {("G2" 13)}
wvSetPosition -win $_nWave2 {("G2" 14)}
wvMoveSelected -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 14)}
wvSetPosition -win $_nWave2 {("G2" 15)}
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvSelectSignal -win $_nWave2 {( "G2" 15 )} 
wvSetRadix -win $_nWave2 -format UDec
wvSetCursor -win $_nWave2 5065681.681601 -snap {("G2" 16)}
wvSetCursor -win $_nWave2 5074393.124198 -snap {("G2" 16)}
wvSetCursor -win $_nWave2 4972405.503550 -snap {("G2" 14)}
wvSetCursor -win $_nWave2 4964331.483582 -snap {("G2" 14)}
wvSelectSignal -win $_nWave2 {( "G2" 14 )} 
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSetCursor -win $_nWave2 5015495.273273 -snap {("G2" 16)}
wvSelectSignal -win $_nWave2 {( "G2" 16 )} 
wvScrollDown -win $_nWave2 5
wvScrollUp -win $_nWave2 5
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvGetSignalSetSignalFilter -win $_nWave2 "*csr*"
wvSetPosition -win $_nWave2 {("G2" 17)}
wvSetPosition -win $_nWave2 {("G2" 17)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_data\[23:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_wd_data\[23:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_req} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_independent_ack} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_paddr\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_psel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwrite} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSelectSignal -win $_nWave2 {( "G2" 16 17 )} 
wvSetPosition -win $_nWave2 {("G2" 17)}
wvGetSignalClose -win $_nWave2
wvScrollUp -win $_nWave2 2
wvScrollUp -win $_nWave2 2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSelectSignal -win $_nWave2 {( "G2" 16 17 )} 
wvSetRadix -win $_nWave2 -format Hex
wvSelectSignal -win $_nWave2 {( "G2" 16 17 )} 
wvSetRadix -win $_nWave2 -format UDec
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSetCursor -win $_nWave2 5016093.881263 -snap {("G2" 18)}
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoom -win $_nWave2 3660730.213200 4034795.228329
wvSetCursor -win $_nWave2 4153772.199649 -snap {("G2" 17)}
wvZoomAll -win $_nWave2
wvZoom -win $_nWave2 0.000000 362178619.756428
wvZoom -win $_nWave2 0.000000 19113621.340326
wvZoom -win $_nWave2 3840829.186791 5185766.006408
wvZoom -win $_nWave2 4948263.631630 5082029.336964
wvSetCursor -win $_nWave2 5057140.589355 -snap {("G2" 13)}
wvZoomOut -win $_nWave2
wvZoomIn -win $_nWave2
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvZoomOut -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G3" 4 )} 
wvSelectSignal -win $_nWave2 {( "G3" 5 )} 
wvSelectSignal -win $_nWave2 {( "G3" 6 )} 
wvSelectSignal -win $_nWave2 {( "G3" 8 )} 
wvSetCursor -win $_nWave2 4975179.680863 -snap {("G2" 22)}
wvSetCursor -win $_nWave2 4983868.116392 -snap {("G2" 22)}
wvSetCursor -win $_nWave2 4994185.633583 -snap {("G2" 22)}
wvSetCursor -win $_nWave2 5004141.132627 -snap {("G2" 22)}
wvSelectSignal -win $_nWave2 {( "G3" 5 )} 
wvSelectSignal -win $_nWave2 {( "G3" 3 )} 
wvSelectSignal -win $_nWave2 {( "G3" 4 )} 
wvSetCursor -win $_nWave2 4965405.190892 -snap {("G2" 22)}
wvSelectSignal -win $_nWave2 {( "G2" 22 )} 
wvSetPosition -win $_nWave2 {("G2" 22)}
wvCollapseBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 22)}
wvSelectSignal -win $_nWave2 {( "G2" 22 )} 
wvExpandBus -win $_nWave2
wvSetCursor -win $_nWave2 4975179.680863 -snap {("G2" 22)}
wvSelectSignal -win $_nWave2 {( "G2" 21 )} 
wvSelectSignal -win $_nWave2 {( "G2" 22 )} 
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoom -win $_nWave2 3129793.876861 4100641.001353
wvZoom -win $_nWave2 3635580.267834 3952189.411275
wvZoomOut -win $_nWave2
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvZoom -win $_nWave2 4953709.862603 5024586.172194
wvZoomOut -win $_nWave2
wvSetCursor -win $_nWave2 4985599.406499 -snap {("G2" 26)}
wvSetCursor -win $_nWave2 4965746.367141 -snap {("G2" 22)}
wvSelectSignal -win $_nWave2 {( "G2" 22 )} 
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G2" 23 )} 
wvSelectSignal -win $_nWave2 {( "G2" 24 )} 
wvSetCursor -win $_nWave2 4994806.613157 -snap {("G2" 23)}
wvSetCursor -win $_nWave2 4985119.864485 -snap {("G2" 22)}
wvSelectSignal -win $_nWave2 {( "G2" 23 )} 
wvSelectSignal -win $_nWave2 {( "G2" 26 )} 
wvSelectSignal -win $_nWave2 {( "G2" 21 )} 
wvSelectSignal -win $_nWave2 {( "G2" 22 )} 
wvSetPosition -win $_nWave2 {("G2" 22)}
wvCollapseBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 22)}
wvSelectSignal -win $_nWave2 {( "G2" 22 )} 
wvExpandBus -win $_nWave2
wvSetCursor -win $_nWave2 4964787.283114 -snap {("G2" 22)}
wvSelectSignal -win $_nWave2 {( "G2" 22 )} 
wvSelectSignal -win $_nWave2 {( "G2" 22 )} 
wvSetRadix -win $_nWave2 -format Bin
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomOut -win $_nWave2
wvScrollDown -win $_nWave2 4
wvScrollDown -win $_nWave2 4
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 2
wvSelectGroup -win $_nWave2 {G3}
wvSelectSignal -win $_nWave2 {( "G3" 1 )} 
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSetCursor -win $_nWave2 5534694.193599 -snap {("G2" 13)}
wvZoom -win $_nWave2 5071264.791784 5961294.768780
wvZoomOut -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSetCursor -win $_nWave2 4824970.975416 -snap {("G3" 1)}
wvZoomAll -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G2" 18 )} 
wvZoom -win $_nWave2 4453676.319350 6320690.020298
wvZoom -win $_nWave2 4864217.221114 5138332.223216
wvZoomOut -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G3" 1 )} 
wvZoom -win $_nWave2 4941555.486253 5171530.183550
wvScrollDown -win $_nWave2 1
wvZoomOut -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoom -win $_nWave2 4460465.460081 9375803.349120
wvZoom -win $_nWave2 5385001.274122 6987973.440913
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvZoom -win $_nWave2 5017175.000000 6592255.649526
wvZoom -win $_nWave2 5504192.494475 5848408.360373
wvSetCursor -win $_nWave2 5673971.497342 -snap {("G2" 15)}
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSetCursor -win $_nWave2 5634146.792966 -snap {("G3" 3)}
wvZoomAll -win $_nWave2
wvZoom -win $_nWave2 4854235.622463 5770769.621110
wvZoom -win $_nWave2 4879288.378582 5039898.869550
wvZoomOut -win $_nWave2
wvZoomIn -win $_nWave2
wvSetCursor -win $_nWave2 4965135.664011 -snap {("G2" 13)}
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoom -win $_nWave2 2980432.780785 3333468.098782
wvZoom -win $_nWave2 3096518.819043 3134019.864324
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomOut -win $_nWave2
wvZoom -win $_nWave2 3179468.876861 4130620.771313
wvSetCursor -win $_nWave2 3753506.420738 -snap {("G2" 14)}
wvSelectSignal -win $_nWave2 {( "G2" 27 )} 
wvSelectSignal -win $_nWave2 {( "G3" 8 )} 
wvSelectSignal -win $_nWave2 {( "G3" 1 )} 
wvSetCursor -win $_nWave2 3765090.137991 -snap {("G2" 22)}
wvSetCursor -win $_nWave2 3752219.341043 -snap {("G2" 22)}
wvSelectSignal -win $_nWave2 {( "G3" 2 )} 
wvSelectSignal -win $_nWave2 {( "G3" 4 )} 
wvSetCursor -win $_nWave2 3756080.580127 -snap {("G2" 14)}
wvSelectSignal -win $_nWave2 {( "G2" 27 )} 
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSelectSignal -win $_nWave2 {( "G2" 22 )} 
wvSelectSignal -win $_nWave2 {( "G2" 22 )} 
wvSetRadix -win $_nWave2 -format Hex
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvSelectSignal -win $_nWave2 {( "G3" 8 )} 
wvSetCursor -win $_nWave2 3815286.246088 -snap {("G2" 14)}
wvSetCursor -win $_nWave2 3825582.883646 -snap {("G2" 14)}
wvSetCursor -win $_nWave2 3852611.557237 -snap {("G2" 14)}
wvSetCursor -win $_nWave2 3756080.580127 -snap {("G2" 22)}
wvSelectSignal -win $_nWave2 {( "G2" 22 )} 
wvSelectSignal -win $_nWave2 {( "G2" 22 )} 
wvSetRadix -win $_nWave2 -format Bin
wvZoom -win $_nWave2 3736130.844858 3803058.988987
wvZoomOut -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomOut -win $_nWave2
wvScrollDown -win $_nWave2 1
wvZoomOut -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G2" 22 )} 
wvZoomOut -win $_nWave2
wvSetCursor -win $_nWave2 3850017.368866 -snap {("G2" 14)}
wvSetCursor -win $_nWave2 3915587.025631 -snap {("G2" 23)}
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 3
wvSelectSignal -win $_nWave2 {( "G3" 16 )} 
wvSelectSignal -win $_nWave2 {( "G3" 17 )} 
wvSetPosition -win $_nWave2 {("G3" 0)}
wvSetPosition -win $_nWave2 {("G3" 16)}
wvSetPosition -win $_nWave2 {("G3" 0)}
wvSetPosition -win $_nWave2 {("G2" 27)}
wvSetPosition -win $_nWave2 {("G2" 26)}
wvSetPosition -win $_nWave2 {("G2" 15)}
wvSetPosition -win $_nWave2 {("G2" 14)}
wvSetPosition -win $_nWave2 {("G2" 13)}
wvSetPosition -win $_nWave2 {("G2" 12)}
wvSetPosition -win $_nWave2 {("G2" 26)}
wvSetPosition -win $_nWave2 {("G2" 11)}
wvSetPosition -win $_nWave2 {("G2" 10)}
wvSetPosition -win $_nWave2 {("G2" 9)}
wvSetPosition -win $_nWave2 {("G2" 8)}
wvSetPosition -win $_nWave2 {("G2" 7)}
wvSetPosition -win $_nWave2 {("G2" 6)}
wvSetPosition -win $_nWave2 {("G2" 5)}
wvSetPosition -win $_nWave2 {("G2" 7)}
wvSetPosition -win $_nWave2 {("G2" 8)}
wvSetPosition -win $_nWave2 {("G2" 9)}
wvSetPosition -win $_nWave2 {("G2" 10)}
wvSetPosition -win $_nWave2 {("G2" 11)}
wvSetPosition -win $_nWave2 {("G2" 12)}
wvSetPosition -win $_nWave2 {("G2" 13)}
wvSetPosition -win $_nWave2 {("G2" 15)}
wvSetPosition -win $_nWave2 {("G2" 16)}
wvSetPosition -win $_nWave2 {("G2" 17)}
wvSetPosition -win $_nWave2 {("G2" 18)}
wvSetPosition -win $_nWave2 {("G2" 17)}
wvSetPosition -win $_nWave2 {("G2" 16)}
wvSetPosition -win $_nWave2 {("G2" 15)}
wvSetPosition -win $_nWave2 {("G2" 14)}
wvSetPosition -win $_nWave2 {("G2" 13)}
wvSetPosition -win $_nWave2 {("G2" 12)}
wvSetPosition -win $_nWave2 {("G2" 11)}
wvSetPosition -win $_nWave2 {("G2" 10)}
wvSetPosition -win $_nWave2 {("G2" 11)}
wvSetPosition -win $_nWave2 {("G2" 13)}
wvSetPosition -win $_nWave2 {("G2" 16)}
wvSetPosition -win $_nWave2 {("G2" 17)}
wvSetPosition -win $_nWave2 {("G2" 18)}
wvSetPosition -win $_nWave2 {("G2" 19)}
wvSetPosition -win $_nWave2 {("G2" 20)}
wvSetPosition -win $_nWave2 {("G2" 21)}
wvSetPosition -win $_nWave2 {("G2" 22)}
wvMoveSelected -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 22)}
wvSetPosition -win $_nWave2 {("G2" 23)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvSetCursor -win $_nWave2 3817051.408835 -snap {("G2" 21)}
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoom -win $_nWave2 3550720.602165 4222845.534506
wvZoom -win $_nWave2 3729438.530724 3945446.205191
wvZoomOut -win $_nWave2
wvSetCursor -win $_nWave2 3755306.838153 -snap {("G2" 22)}
wvSelectSignal -win $_nWave2 {( "G2" 22 )} 
wvSelectSignal -win $_nWave2 {( "G2" 22 )} 
wvSetRadix -win $_nWave2 -format Hex
wvSetCursor -win $_nWave2 4964920.585441 -snap {("G2" 22)}
wvZoom -win $_nWave2 4947675.047155 5005842.201714
wvZoomOut -win $_nWave2
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvZoomOut -win $_nWave2
wvScrollDown -win $_nWave2 1
wvSelectSignal -win $_nWave2 {( "G3" 5 )} 
wvSelectSignal -win $_nWave2 {( "G3" 2 )} 
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G2" 13 )} 
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvGetSignalSetSignalFilter -win $_nWave2 "*csr*"
wvSetPosition -win $_nWave2 {("G2" 23)}
wvSetPosition -win $_nWave2 {("G2" 23)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_data\[23:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_wd_data\[23:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_req} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_independent_ack} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_paddr\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_psel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwrite} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSetPosition -win $_nWave2 {("G2" 23)}
wvGetSignalSetSignalFilter -win $_nWave2 "*css*"
wvSetPosition -win $_nWave2 {("G2" 23)}
wvSetPosition -win $_nWave2 {("G2" 23)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_data\[23:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_wd_data\[23:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_req} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_independent_ack} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_paddr\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_psel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwrite} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSetPosition -win $_nWave2 {("G2" 23)}
wvGetSignalSetSignalFilter -win $_nWave2 "*csn*"
wvSetPosition -win $_nWave2 {("G2" 23)}
wvSetPosition -win $_nWave2 {("G2" 23)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_data\[23:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_wd_data\[23:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_req} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_independent_ack} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_paddr\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_psel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwrite} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSetPosition -win $_nWave2 {("G2" 23)}
wvSetPosition -win $_nWave2 {("G2" 24)}
wvSetPosition -win $_nWave2 {("G2" 24)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_data\[23:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_wd_data\[23:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csn} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[32\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_req} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_independent_ack} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_paddr\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_psel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwrite} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSelectSignal -win $_nWave2 {( "G2" 24 )} 
wvSetPosition -win $_nWave2 {("G2" 24)}
wvGetSignalClose -win $_nWave2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSetCursor -win $_nWave2 3914511.459779 -snap {("G2" 13)}
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G3" 8 )} 
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G3" 1 )} 
wvZoomOut -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomOut -win $_nWave2
wvZoom -win $_nWave2 4994387.686062 5609443.504736
wvZoomOut -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomOut -win $_nWave2
wvSetCursor -win $_nWave2 5666870.908645 -snap {("G2" 13)}
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvUnknownSaveResult -win $_nWave2 -clear
wvSelectSignal -win $_nWave2 {( "G2" 24 )} 
wvSelectSignal -win $_nWave2 {( "G2" 26 )} 
wvSelectSignal -win $_nWave2 {( "G2" 24 )} 
wvSelectSignal -win $_nWave2 {( "G2" 26 )} 
wvSelectSignal -win $_nWave2 {( "G2" 24 )} 
wvGetSignalOpen -win $_nWave2
wvGetSignalSetSignalFilter -win $_nWave2 "*data_out*"
wvSetPosition -win $_nWave2 {("G2" 24)}
wvSetPosition -win $_nWave2 {("G2" 24)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_data\[23:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_wd_data\[23:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csn} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_req} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_independent_ack} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_paddr\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_psel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwrite} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSetPosition -win $_nWave2 {("G2" 24)}
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvSetPosition -win $_nWave2 {("G2" 24)}
wvSetPosition -win $_nWave2 {("G2" 24)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_data\[23:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_wd_data\[23:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csn} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_req} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_independent_ack} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_paddr\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_psel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwrite} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSelectSignal -win $_nWave2 {( "G2" 24 )} 
wvSetPosition -win $_nWave2 {("G2" 24)}
wvGetSignalClose -win $_nWave2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvSelectSignal -win $_nWave2 {( "G2" 24 )} 
wvExpandBus -win $_nWave2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 2
wvSelectSignal -win $_nWave2 {( "G2" 26 27 28 29 30 31 32 33 34 35 36 37 38 39 \
           40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 )} 
wvSelectSignal -win $_nWave2 {( "G2" 27 28 29 30 31 32 33 34 35 36 37 38 39 40 \
           41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 )} 
wvSelectSignal -win $_nWave2 {( "G2" 28 29 30 31 32 33 34 35 36 37 38 39 40 41 \
           42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 )} 
wvSelectSignal -win $_nWave2 {( "G2" 29 30 31 32 33 34 35 36 37 38 39 40 41 42 \
           43 44 45 46 47 48 49 50 51 52 53 54 55 56 )} 
wvCut -win $_nWave2
wvSetPosition -win $_nWave2 {("G3" 23)}
wvSetPosition -win $_nWave2 {("G2" 28)}
wvSelectSignal -win $_nWave2 {( "G2" 29 )} 
wvSelectSignal -win $_nWave2 {( "G2" 29 30 )} 
wvSelectSignal -win $_nWave2 {( "G2" 29 30 31 )} 
wvCut -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 28)}
wvSelectSignal -win $_nWave2 {( "G2" 27 )} 
wvZoom -win $_nWave2 4994387.686062 5191436.400088
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSelectSignal -win $_nWave2 {( "G3" 3 )} 
wvSetCursor -win $_nWave2 5551536.925516 -snap {("G3" 2)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSetCursor -win $_nWave2 5877907.190695 -snap {("G2" 13)}
wvSetCursor -win $_nWave2 5862975.217778 -snap {("G2" 13)}
wvSetCursor -win $_nWave2 6089087.950517 -snap {("G2" 13)}
wvSetCursor -win $_nWave2 6272537.903493 -snap {("G2" 13)}
wvSetCursor -win $_nWave2 6485851.802303 -snap {("G2" 13)}
wvSetCursor -win $_nWave2 6278937.320457 -snap {("G2" 13)}
wvSetCursor -win $_nWave2 6080555.394564 -snap {("G2" 13)}
wvSetCursor -win $_nWave2 6057090.865695 -snap {("G2" 13)}
wvSetCursor -win $_nWave2 5860842.078790 -snap {("G2" 13)}
wvSetCursor -win $_nWave2 5649661.318968 -snap {("G2" 13)}
wvSetCursor -win $_nWave2 5555803.203492 -snap {("G2" 13)}
wvSetCursor -win $_nWave2 5594199.705278 -snap {("G2" 13)}
wvSetCursor -win $_nWave2 5555803.203492 -snap {("G2" 13)}
wvSetCursor -win $_nWave2 5547270.647540 -snap {("G2" 13)}
wvZoom -win $_nWave2 5457678.810039 6101886.784445
wvZoomOut -win $_nWave2
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSetCursor -win $_nWave2 6894811.108723 -snap {("G2" 10)}
wvSetCursor -win $_nWave2 7105769.606431 -snap {("G2" 11)}
wvZoom -win $_nWave2 7097924.042467 7155458.178205
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G3" 1 )} 
wvSetCursor -win $_nWave2 7248143.413112 -snap {("G3" 1)}
wvSetCursor -win $_nWave2 7267606.923172 -snap {("G2" 13)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvSelectSignal -win $_nWave2 {( "G3" 2 )} 
wvSetCursor -win $_nWave2 7250074.193311 -snap {("G3" 1)}
wvSetCursor -win $_nWave2 7271250.492256 -snap {("G3" 1)}
wvSetCursor -win $_nWave2 7265022.169037 -snap {("G2" 13)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvGetSignalSetSignalFilter -win $_nWave2 "*reg_data*"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_csr"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvSetPosition -win $_nWave2 {("G2" 23)}
wvSetPosition -win $_nWave2 {("G2" 23)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_data\[23:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_wd_data\[23:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_in\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csn} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[28\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_req} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_independent_ack} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_paddr\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_psel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwrite} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSelectSignal -win $_nWave2 {( "G2" 23 )} 
wvSetPosition -win $_nWave2 {("G2" 23)}
wvGetSignalClose -win $_nWave2
wvScrollUp -win $_nWave2 5
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvGetSignalSetSignalFilter -win $_nWave2 "*reg_rdata*"
wvSetPosition -win $_nWave2 {("G2" 23)}
wvSetPosition -win $_nWave2 {("G2" 23)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_data\[23:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_wd_data\[23:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_in\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csn} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[28\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_req} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_independent_ack} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_paddr\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_psel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwrite} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSetPosition -win $_nWave2 {("G2" 23)}
wvSetPosition -win $_nWave2 {("G2" 24)}
wvSetPosition -win $_nWave2 {("G2" 24)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_data\[23:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_wd_data\[23:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_in\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csn} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[28\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_req} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_independent_ack} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_paddr\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_psel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwrite} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSelectSignal -win $_nWave2 {( "G2" 24 )} 
wvSetPosition -win $_nWave2 {("G2" 24)}
wvGetSignalClose -win $_nWave2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSetCursor -win $_nWave2 7274987.486188 -snap {("G2" 24)}
wvSetCursor -win $_nWave2 7271873.324578 -snap {("G3" 1)}
wvSetCursor -win $_nWave2 7339450.631508 -snap {("G3" 1)}
wvSetCursor -win $_nWave2 7264710.752876 -snap {("G2" 13)}
wvSetCursor -win $_nWave2 7274676.070027 -snap {("G2" 24)}
wvSetCursor -win $_nWave2 7268447.746808 -snap {("G3" 1)}
wvScrollUp -win $_nWave2 1
wvSetCursor -win $_nWave2 7288066.964949 -snap {("G2" 24)}
wvScrollUp -win $_nWave2 1
wvSetCursor -win $_nWave2 7270004.827613 -snap {("G3" 1)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSelectSignal -win $_nWave2 {( "G1" 1 )} 
wvSetPosition -win $_nWave2 {("G1" 1)}
wvSetPosition -win $_nWave2 {("G1" 2)}
wvSetPosition -win $_nWave2 {("G2" 1)}
wvSetPosition -win $_nWave2 {("G2" 6)}
wvSetPosition -win $_nWave2 {("G2" 14)}
wvSetPosition -win $_nWave2 {("G2" 15)}
wvSetPosition -win $_nWave2 {("G2" 16)}
wvSetPosition -win $_nWave2 {("G2" 19)}
wvSetPosition -win $_nWave2 {("G2" 24)}
wvSetPosition -win $_nWave2 {("G2" 23)}
wvSetPosition -win $_nWave2 {("G2" 22)}
wvSetPosition -win $_nWave2 {("G2" 24)}
wvSetPosition -win $_nWave2 {("G2" 18)}
wvSetPosition -win $_nWave2 {("G2" 19)}
wvSetPosition -win $_nWave2 {("G2" 20)}
wvSetPosition -win $_nWave2 {("G2" 23)}
wvSetPosition -win $_nWave2 {("G2" 25)}
wvSetPosition -win $_nWave2 {("G2" 26)}
wvSetPosition -win $_nWave2 {("G2" 23)}
wvSetPosition -win $_nWave2 {("G2" 24)}
wvSetPosition -win $_nWave2 {("G2" 25)}
wvSetPosition -win $_nWave2 {("G2" 26)}
wvSetPosition -win $_nWave2 {("G2" 24)}
wvSetPosition -win $_nWave2 {("G2" 27)}
wvSetPosition -win $_nWave2 {("G2" 28)}
wvSetPosition -win $_nWave2 {("G2" 27)}
wvSetPosition -win $_nWave2 {("G2" 26)}
wvSetPosition -win $_nWave2 {("G2" 25)}
wvSetPosition -win $_nWave2 {("G2" 24)}
wvSetPosition -win $_nWave2 {("G2" 23)}
wvSetPosition -win $_nWave2 {("G2" 22)}
wvSetPosition -win $_nWave2 {("G2" 19)}
wvSetPosition -win $_nWave2 {("G2" 18)}
wvMoveSelected -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 19)}
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvSetCursor -win $_nWave2 7265956.417520 -snap {("G2" 15)}
wvScrollDown -win $_nWave2 2
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvSetCursor -win $_nWave2 7274987.486188 -snap {("G2" 25)}
wvSetCursor -win $_nWave2 7270316.243774 -snap {("G3" 1)}
wvZoom -win $_nWave2 7257236.765013 7385228.807170
wvZoomOut -win $_nWave2
wvZoomIn -win $_nWave2
wvSetCursor -win $_nWave2 7316729.683119 -snap {("G2" 12)}
verdiFindBar -show -win nWave_2
verdiFindBar -hide -win nWave_2
wvGetSignalOpen -win $_nWave2
wvGetSignalSetScope -win $_nWave2 "/test_top"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo"
wvGetSignalSetScope -win $_nWave2 \
           "/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvGetSignalSetScope -win $_nWave2 "/test_top/u_dut_wrapper/u_dut/u_qspi_fsm"
wvGetSignalSetSignalFilter -win $_nWave2 "*reg_data*"
wvSetPosition -win $_nWave2 {("G2" 19)}
wvSetPosition -win $_nWave2 {("G2" 19)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_data\[23:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_wd_data\[23:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_in\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csn} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[28\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_req} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_independent_ack} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_paddr\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_psel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwrite} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSetPosition -win $_nWave2 {("G2" 19)}
wvSetPosition -win $_nWave2 {("G2" 19)}
wvSetPosition -win $_nWave2 {("G2" 19)}
wvAddSignal -win $_nWave2 -clear
wvAddSignal -win $_nWave2 -group {"G1" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_sclk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_araddr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arburst\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arid\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arlen\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_arvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_arready} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G2" \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/o_rvalid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_rready} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_wr_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/reg_rd_cnt\[2:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/i_re} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_sel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_arb_write_en} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/o_req_read} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_read_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_axi_sclk_logic/i_sram_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_state\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_cmd\[4:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_data\[23:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_wd_data\[23:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_cnt_addr\[7:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out_cnt\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/i_clk} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_we} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_ax_oe} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_axi_ctrl/u_arfifo/o_write_valid} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_in\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_rdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csn} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[31\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[30\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[29\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_data_out\[28\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_write_cmd\[15:0\]} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G3" \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_qspi_si\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_cs_n} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_oe\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[3\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[2\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_qspi_so\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[1\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_mode_status_current\[0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/o_independent_mode\[1:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_independent_cmd\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/i_csr_independent_req} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/o_csr_independent_ack} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_ctrl_cmd_2bytes} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_ax_addr\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_qspi_fsm/reg_csr_wd_addr\[5:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_paddr\[15:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_psel} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwdata\[31:0\]} -height 16 \
{/test_top/u_dut_wrapper/u_dut/u_csr/i_pwrite} -height 16 \
}
wvAddSignal -win $_nWave2 -group {"G4" \
}
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetPosition -win $_nWave2 {("G2" 19)}
wvGetSignalClose -win $_nWave2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSelectSignal -win $_nWave2 {( "G2" 19 )} 
wvSetRadix -win $_nWave2 -format UDec
wvSetCursor -win $_nWave2 7344874.076692 -snap {("G2" 19)}
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvZoomOut -win $_nWave2
wvSelectSignal -win $_nWave2 {( "G2" 26 )} 
wvSetCursor -win $_nWave2 7272911.027279 -snap {("G2" 26)}
wvSelectSignal -win $_nWave2 {( "G2" 26 )} 
wvSetPosition -win $_nWave2 {("G2" 26)}
wvExpandBus -win $_nWave2
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 4
wvSelectSignal -win $_nWave2 {( "G2" 26 )} 
wvSetPosition -win $_nWave2 {("G2" 26)}
wvCollapseBus -win $_nWave2
wvSetPosition -win $_nWave2 {("G2" 26)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvDisplayGridCount -win $_nWave2 -off
wvCloseGetStreamsDialog -win $_nWave2
wvAttrOrderConfigDlg -win $_nWave2 -close
wvCloseDetailsViewDlg -win $_nWave2
wvCloseDetailsViewDlg -win $_nWave2 -streamLevel
wvCloseFilterColorizeDlg -win $_nWave2
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSetCursor -win $_nWave2 7285889.139062 -snap {("G2" 26)}
wvSetCursor -win $_nWave2 7275251.730732 -snap {("G2" 26)}
wvSetCursor -win $_nWave2 7284859.712449 -snap {("G2" 26)}
wvSelectSignal -win $_nWave2 {( "G2" 26 )} 
wvSelectSignal -win $_nWave2 {( "G2" 26 )} 
wvSetRadix -win $_nWave2 -format Bin
